
import React from "react";
import ReactDOM from "react-dom/client";
import RoyalFoodsApp from "./RoyalFoodsApp";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RoyalFoodsApp />
  </React.StrictMode>
);
